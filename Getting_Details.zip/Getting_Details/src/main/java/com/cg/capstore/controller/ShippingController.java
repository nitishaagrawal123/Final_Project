package com.cg.capstore.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.Customer;
import com.cg.capstore.bean.Product;
import com.cg.capstore.dao.AddressDao;
import com.cg.capstore.dao.CartDao;
import com.cg.capstore.dao.CustomerDao;

@Repository
@Controller
public class ShippingController {
	@Autowired
	AddressDao dao;
	@Autowired 
	CustomerDao customerDaoRef;
	
	@Autowired
	CartDao cartDaoRef;
	
	@RequestMapping(method = RequestMethod.GET, value = "cartdetails/{id}")
	public ArrayList<Product> list(@PathVariable(name = "id") int id,ModelMap modelMap) {

		List<Cart> customerCart = new ArrayList<Cart>();
		ArrayList<Product> products = new ArrayList<Product>();

		Customer customer = customerDaoRef.getOne(id);

		customerCart = cartDaoRef.getCartDetailsOfSpecificCustomer(customer);

		for (Cart c : customerCart) {
			Product p = (Product)c.getProducts();
			p.setPrice(p.getPrice());
			p.setProductQuantity(c.getQuantity());
			products.add(p);
			System.out.println(c.getProducts().getProductBrand());
		}
               modelMap.put("products", products);
              return "success.jsp";
				
	}
}
