package com.cg.capstore.dao;

import java.util.List;

import org.jboss.logging.Param;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.capstore.bean.Cart;
import com.cg.capstore.bean.Customer;

public interface CartDao extends JpaRepository<Cart, String> {
	@Query("select cart from Cart cart where cart.customer = :customer")
	List<Cart> getCartDetailsOfSpecificCustomer(@RequestParam("customer") Customer customer);
	
	
}